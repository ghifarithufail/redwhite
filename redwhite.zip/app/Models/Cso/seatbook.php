<?php

namespace App\Models\Cso;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class seatbook extends Model
{
    use HasFactory;
}
