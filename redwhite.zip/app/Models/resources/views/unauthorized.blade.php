<!DOCTYPE html>
<html>
<head>
    <title>Unauthorized Access</title>
</head>
<body>
    <h1>Anda tidak punya Akses</h1>
    <p>You do not have permission to access this page.</p>
</body>
</html>
