<div class="btn-group" role="group">
    <button id="btnGroupDrop1" type="button" class="btn btn-primary dropdown-toggle btn-sm" data-bs-toggle="dropdown"
        aria-expanded="false">
        Action
    </button>
    <ul class="dropdown-menu" aria-labelledby="btnGroupDrop1">
        <?php if($showEdit): ?>
            <li><a class="dropdown-item" href="<?php echo e($routeEdit); ?>">Edit</a></li>
        <?php endif; ?>
        <?php if($showDelete): ?>
            <li>
                <form action="<?php echo e($routeDelete); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="dropdown-item" type="submit">Delete</button>
                </form>
            </li>
        <?php endif; ?>
    </ul>
</div><?php /**PATH D:\tufa\pariwisata-3624\resources\views\components\action.blade.php ENDPATH**/ ?>