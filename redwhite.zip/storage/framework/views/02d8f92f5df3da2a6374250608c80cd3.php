<?php $__env->startSection('content'); ?>

    <head>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    </head>
    <div class="card mt-4">
        <div class="card-body">
            <div class="card-header" style="zoom: 0.8">
                <h4>
                    Booking Detail <?php echo e($booking->start_date); ?>

                </h4>
                <hr>
                <div class="row">
                    <div class="col-xs-12 col-sm-6">

                        <div class="form-group">
                            <label class="control-label col-sm-3">Name :</label>
                            <div class="col-sm-9">
                                <input type="text" value="<?php echo e($booking->customer); ?>" disabled class="form-control" />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-sm-3">Start Date :</label>
                            <div class="col-sm-9">
                                <input type="date"
                                    value="<?php echo e(Carbon\Carbon::parse($booking->date_start)->format('Y-m-d')); ?>" disabled
                                    class="form-control" />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-sm-3">End Date</label>
                            <div class="col-sm-9">
                                <input type="date"
                                    value="<?php echo e(Carbon\Carbon::parse($booking->date_end)->format('Y-m-d')); ?>" disabled
                                    class="form-control" />
                            </div>
                        </div>
                    </div>

                    <div class="col-xs-12 col-sm-6">
                        <div class="form-group">
                            <label class="control-label col-sm-3">Total Penumpang :</label>
                            <div class="col-sm-9">
                                <input type="text" value="<?php echo e($booking->total_passanger); ?>" disabled
                                    class="form-control" />
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-sm-4">Penjemputan :</label>
                            <div class="col-sm-9">
                                <input type="text" value="<?php echo e($booking->lokasi_jemput); ?>" disabled class="form-control" />

                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-sm-3">Tujuan :</label>
                            <div class="col-sm-9">
                                <input type="text"
                                    value="<?php $__currentLoopData = $booking->tujuans(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($item->nama_tujuan); ?><?php if(!$loop->last): ?>, <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>"
                                    disabled class="form-control" />
                            </div>
                        </div>
                    </div>

                    <div class="col-xs-12 mt-4">
                        <h4>
                            Detail Bus
                        </h4>
                        <hr>
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Bus</th>
                                    <th>Supir</th>
                                    <th>Kondektur</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                                <?php $__currentLoopData = $booking->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($detail->armadas->nobody); ?></td>
                                        <td><?php echo e($detail->pengemudis ? $detail->pengemudis->nopengemudi : ''); ?> - <?php echo e($detail->pengemudis ? $detail->pengemudis->users->name : ''); ?></td>
                                        <td><?php echo e($detail->kondekturs ? $detail->kondekturs->nokondektur : ''); ?> - <?php echo e($detail->kondekturs ? $detail->kondekturs->users->name : ''); ?></td>
                                        <td class="text-center">
                                            <button type="button" class="btn btn-primary launch-modal"
                                                data-bs-toggle="modal" data-bs-target="#basicModal"
                                                data-supir="<?php echo e($detail->supir_id); ?>"
                                                data-bus="<?php echo e($detail->armadas->nobody); ?>"
                                                data-kondektur="<?php echo e($detail->kondektur_id); ?>"
                                                data-booking-id="<?php echo e($detail->id); ?>"
                                                data-armada-id="<?php echo e($detail->armada_id); ?>">
                                                Input
                                            </button>
                                            <input type="hidden" name="bookingId" id="bookingId"
                                                value="<?php echo e($detail->id); ?>">
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="mt-3">
                            <!-- Modal -->
                            <div class="modal fade" id="basicModal" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <form id="form">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Edit Supir Dan Kondektur</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col mb-3">
                                                        <label for="bus" class="form-label">Bus</label>
                                                        <input type="text" id="bus" class="form-control" disabled>
                                                    </div>
                                                </div>
                                                <div class="row g-2">
                                                    <div class="col mb-0">
                                                        <label for="supir_id" class="form-label">Pengemudi</label>
                                                        <select class="form-select" id="supir_id" name="supir_id">
                                                            <option value="" selected disabled>Silahkan pilih pengemudi</option>
                                                            <?php $__currentLoopData = $pengemudi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->nopengemudi); ?> - <?php echo e($item->users->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="col mb-0">
                                                        <label for="kondektur_id" class="form-label">Kondektur</label>
                                                        <select class="form-select" id="kondektur_id" name="kondektur_id">
                                                            <option value="" selected disabled>Silahkan pilih Kondektur</option>
                                                            <?php $__currentLoopData = $kondektur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->nokondektur); ?> - <?php echo e($item->users->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                                                <button type="button" class="btn btn-primary" id="saveChangesBtn">Save changes</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            
                        </div>

                        <script>
                            document.querySelectorAll('.launch-modal').forEach(item => {
                                item.addEventListener('click', event => {
                                    const supirId = item.getAttribute('data-supir');
                                    const bus = item.getAttribute('data-bus');
                                    const kondekturId = item.getAttribute('data-kondektur');

                                    document.getElementById('bus').value = bus;
                                    document.getElementById('supir_id').value = supirId;
                                    document.getElementById('kondektur_id').value = kondekturId;
                                });
                            });
                        </script>

                    </div>
                </div>
            </div>
        </div>
        <script>
            $(document).ready(function() {
                $('.launch-modal').click(function() {
                    var supirId = $(this).data('supir');
                    var bus = $(this).data('bus');
                    var kondekturId = $(this).data('kondektur');
                    var bookingId = $(this).data('booking-id');
        
                    $('#bus').val(bus);
                    $('#supir_id').val(supirId);
                    $('#kondektur_id').val(kondekturId);
                    $('#bookingId').val(bookingId);
                });
        
                $('#saveChangesBtn').click(function() {
                    var bookingId = $('#bookingId').val();
                    var supirId = $('#supir_id').val();
                    var kondekturId = $('#kondektur_id').val();
        
                    $.ajax({
                        url: '/update-data',
                        method: "POST",
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        data: {
                            booking_id: bookingId,
                            supir_id: supirId,
                            kondektur_id: kondekturId
                        },
                        success: function(response) {
                            alert("Data saved, page will be refreshed");
                            location.reload();
                        },
                        error: function(response) {
                            var response = response.responseJSON;
                            alert(response.error.e);
                        }
                    });
                });
            });
        </script>
        
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u481311413/domains/primajasagroup.com/public_html/redwhite/resources/views/layouts/booking/edit.blade.php ENDPATH**/ ?>