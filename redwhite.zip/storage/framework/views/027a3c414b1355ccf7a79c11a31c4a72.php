<?php $__env->startSection('content'); ?>
    <div class="card text-center">
        <h5 class="card-header">Jadwal Supir</h5>
    </div>
    <div class="card mt-4">
        <div class="table-responsive text-nowrap">
            <table class="table table-hover" style="zoom: 0.75">
                <thead>
                    <tr>
                        <th>Supir</th>
                        <th>No Booking</th>
                        <th>Bus</th>
                        <th>Tujuan</th>
                        <th>Tanggal Mulai</th>
                        <th>Tanggal Akhir</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->pengemudis ? $data->pengemudis->users->name : ''); ?></td>
                            <td><?php echo e($data->bookings->no_booking); ?></td>
                            <td><?php echo e($data->armadas->nobody); ?></td>
                            <td><?php echo e($data->bookings->tujuan->nama_tujuan); ?></td>
                            <td><?php echo e($data->bookings->date_start); ?></td>
                            <td><?php echo e($data->bookings->date_end); ?></td>
                            <td>
                                <div class="dropdown text-center">
                                    <a href="<?php echo e(route('booking/edit', $data->id)); ?>">
                                        <button type="button" class="btn rounded-pill btn-warning"
                                            fdprocessedid="c80zr4">detail</button>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pariwisata\resources\views/layouts/jadwal/index.blade.php ENDPATH**/ ?>