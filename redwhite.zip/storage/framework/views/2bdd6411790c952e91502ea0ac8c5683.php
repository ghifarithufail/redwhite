<!DOCTYPE html>
<html>
<head>
    <title>Jadwal Bus</title>
    <style>
        .page-break {
            page-break-before: always;
        }
        .small-text {
            font-size: 10px !important;
        }
    </style>
</head>
<body>


    <?php $__currentLoopData = $typearmadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typearmada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!$loop->first): ?>
            <div class="page-break"></div>
        <?php endif; ?>
        <h3>Jadwal Bus</h3>
        <p>Periode: <?php echo e($date_start); ?> - <?php echo e($date_end); ?></p>
        <h5>Type Armada: <?php echo e($typearmada->name); ?></h5>
        <table border="1" cellspacing="0" cellpadding="5">
            <thead>
                <tr>
                    <th class="small-text">Armada</th>
                    <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="small-text"><?php echo e($day); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $armadas->where('type_id', $typearmada->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $armada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="small-text"><?php echo e($armada->nobody); ?></td>
                        <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="small-text"><?php echo e($schedule[$armada->id][$date]); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="small-text"><strong>Total Armada</strong></td>
                    <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="small-text"><strong><?php echo e($totalArmadas[$date] ?? 0); ?></strong></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </tbody>
        </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>
<?php /**PATH D:\tufa\pariwisata-3624\resources\views/layouts/Operasi/jadwalbus/pdf.blade.php ENDPATH**/ ?>