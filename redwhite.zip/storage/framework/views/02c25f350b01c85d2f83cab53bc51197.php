<?php $__env->startSection('content'); ?>
    <div class="container-xxl">
        <div class="card mb-4">
            <h5 class="card-header">Edit Jabatan</h5>
            <!-- Account -->
            <div class="card-body">
                <form action="<?php echo e(route('jabatan.update', $jabatan->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row">
                        <!-- Input untuk Jabatan -->
                        <div class="mb-3 col-md-6">
                            <label for="nama_jabatan" class="form-label">Nama Jabatan</label>
                            <input id="nama_jabatan" type="text" name="nama_jabatan" class="form-control"
                                    value="<?php echo e($jabatan->nama_jabatan); ?>" minlength="3" required>
                        </div>
                        <div class="mb-3 col-md-6">
                            <label for="kodejab" class="form-label">Kode Jabatan</label>
                            <input id="kodejab" type="text" name="kodejab" class="form-control"
                                    value="<?php echo e($jabatan->kodejab); ?>" minlength="3" required>
                        </div>

                        <div class="mt-2">
                            <button type="submit" class="btn btn-primary" name="action">Update</button>
                            <a href="<?php echo e(route('jabatan.index')); ?>" class="btn btn-warning">Back</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
    // Jika terdapat pesan sukses dari server, tampilkan pesan toastr
    <?php if(session('success')): ?>
    toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

    // Jika terdapat pesan error dari server, tampilkan pesan toastr
    <?php if(session('error')): ?>
    toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pariwisata-3624\resources\views/layouts/admin/jabatan/edit.blade.php ENDPATH**/ ?>