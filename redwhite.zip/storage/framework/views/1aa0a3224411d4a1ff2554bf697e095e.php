<?php $__env->startSection('content'); ?>

    <div class="container-xxl">
        <div class="card mb-4">
        <h5 class="card-header">Create Biodata</h5>
            <div class="card-body">
                <form action="<?php echo e(route('biodata/store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row g-2">
                        <div class="mb-3 col-md-4">
                            <label for="user_id" class="form-label">User</label>
                            <select id="user_id" name="user_id" class="select2 form-select">
                                <option value="">Pilih User</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $roleName = $user->roles->first()->name ?? 'No Role';
                                    ?>
                                    <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                                        <?php echo e($user->id); ?> - <?php echo e($user->name); ?> - <?php echo e($roleName); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-2 col-md-4">
                            <label for="nik" class="form-label">Nomor KTP</label>
                            <input id="nik" type="text" name="nik" class="form-control" value="<?php echo e(old('nik')); ?>" minlength="3" required>
                            <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger text-sm "><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-2 col-md-4">
                            <label for="nokk" class="form-label">Nomor Kartu Keluarga</label>
                            <input id="nokk" type="text" name="nokk" class="form-control" value="<?php echo e(old('nokk')); ?>" minlength="3" required>
                            <?php $__errorArgs = ['nokk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger text-sm"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="mb-2 col-md-6">
                            <label class="form-label" for="kota_id">Tempat Lahir</label>
                            <select id="kota_id" name="kota_id" class="select2 form-select">
                                <option value=""><?php echo e(__('Select Kota')); ?></option>
                                <?php $__currentLoopData = $kotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>" <?php echo e(old('kota_id') == $data->id ? 'selected' : ''); ?>>
                                        <?php echo e($data->nama_kota); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-2 col-md-6">
                            <label for="tgl_lahir" class="form-label">Tanggal Lahir</label>
                            <input id="tgl_lahir" type="date" name="tgl_lahir" class="form-control" value="<?php echo e(old('tgl_lahir')); ?>" required>
                            <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="mb-2 col-md-4">
                            <label class="form-label" for="nikah">Perkawinan</label>
                            <select id="nikah" name="nikah" class="select2 form-select" required>
                                <option value="Singel" <?php echo e(old('nikah') == 'Singel' ? 'selected' : ''); ?>>Singel</option>
                                <option value="Menikah" <?php echo e(old('nikah') == 'Menikah' ? 'selected' : ''); ?>>Menikah</option>
                                <option value="Cerai" <?php echo e(old('nikah') == 'Cerai' ? 'selected' : ''); ?>>Cerai</option>
                            </select>
                        </div>
                        <div class="mb-2 col-md-4">
                            <label class="form-label" for="status">Agama</label>
                            <select id="agama" name="agama" class="select2 form-select" required>
                                <option value="Islam" <?php echo e(old('agama') == 'Islam' ? 'selected' : ''); ?>>Islam</option>
                                <option value="Kristen" <?php echo e(old('agama') == 'Kristen' ? 'selected' : ''); ?>>Kristen</option>
                                <option value="Hindu" <?php echo e(old('agama') == 'Hindu' ? 'selected' : ''); ?>>Hindu</option>
                                <option value="Budha" <?php echo e(old('agama') == 'Budha' ? 'selected' : ''); ?>>Budha</option>
                            </select>
                        </div>
                        <div class="mb-2 col-md-4">
                            <label class="form-label" for="jenis">Jenis</label>
                            <select id="jenis" name="jenis" class="select2 form-select" required>
                                <option value="Laki" <?php echo e(old('jenis') == 'Laki' ? 'selected' : ''); ?>>Laki</option>
                                <option value="Perempuan" <?php echo e(old('jenis') == 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                            </select>
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="mb-2 col-md-8">
                            <label for="alamat" class="form-label">Alamat</label>
                            <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo e(old('alamat')); ?>"/>
                        </div>
                        <div class="mb-2 col-md-2">
                            <label for="rt" class="form-label">RT</label>
                            <input type="text" class="form-control" id="rt" name="rt" value="<?php echo e(old('rt')); ?>" />
                        </div>
                        <div class="mb-2 col-md-2">
                            <label for="rw" class="form-label">RW</label>
                            <input type="text" class="form-control" id="rw" name="rw" value="<?php echo e(old('rw')); ?>"/>
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="mb-2 col-md-6">
                            <label for="image" class="form-label">Image</label>
                            <input type="file" class="form-control" id="image" name="image">
                        </div>
                    </div>
                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary" name="action">Submit</button>
                        <a href="<?php echo e(route('biodata')); ?>" class="btn btn-warning">Kembali</a>
                    </div>
                </div>
            </form>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <script>
            $(document).ready(function () {
                $('#user_id').select2();
                $('#kota_id').select2();


            });
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tufa\pariwisata\resources\views/layouts/hrd/biodata/create.blade.php ENDPATH**/ ?>