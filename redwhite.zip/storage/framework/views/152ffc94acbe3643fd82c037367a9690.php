<?php $__env->startSection('content'); ?>

    <div class="card text-center">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div class="search-field">
                <form action="<?php echo e(route('kota.index')); ?>" method="GET">
                    <input type="text" name="search" class="form-control" placeholder="Search...">
                </form>
            </div>
            <div>
                <a href="<?php echo e(route('kota.index')); ?>" class="m-0"><h5> Daftar kota</h5></a>
                <p class="m-0">Total : <?php echo e(App\Models\Admin\Kota::count()); ?> </p>
            </div>
            <div class="add-new-role">
                <button
                    class="btn btn-primary" type="button" data-bs-toggle="offcanvas"
                    data-bs-target="#formkota" aria-controls="formkota">
                    + kota
                </button>
            </div>
        </div>
    </div>

    <!-- Tabel -->
    <div class="card mt-4">
        <div class="table-responsive text-nowrap">
            <table class="table table-hover" style="zoom: 0.85">
                <thead>
                    <tr>
                        <th>No.Urt</th>
                        <th>Nama Kota</th>
                        <th>Provinsi</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $kotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($kotas->firstItem() + $loop->index); ?></td>
                        <td><?php echo e($data->nama_kota); ?></td>
                        <td><?php echo e($data->provinsis->nama_provinsi); ?></td>
                        <td>
                            <div class="dropdown text-center">
                                <a href="<?php echo e(route('kota.edit', $data->id)); ?>">
                                    <button type="button" class="btn rounded-pill btn-icon btn-warning">
                                        <span class="tf-icons bx bx-edit"></span>
                                    </button>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="intro-y col-span-12">
            <div class="card-footer">
                <?php echo e($kotas->onEachSide(1)->links('pagination::bootstrap-5')); ?>

            </div>
        </div>
    </div>

    <div class="card">
        <form action="<?php echo e(route('kota.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
          <div class="offcanvas offcanvas-end" data-bs-scroll="true" tabindex="-1"
                id="formkota" aria-labelledby="formkotaLabel">
            <div class="offcanvas-header">
              <h5 id="formkotaLabel" class="offcanvas-title">Input Data kota</h5>
              <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body my-auto">
                <div class="form-group">
                    <label for="nama_kota" class="form-label">Nama kota</label>
                    <input id="nama_kota" type="text" name="nama_kota" class="form-control" value="<?php echo e(old('nama_kota')); ?>" minlength="3" required>
                    <?php $__errorArgs = ['nama_kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label class="form-label" for="pool_id">Pool</label>
                    <select id="provinsi_id" name="provinsi_id" class="select2 form-select" data-allow-clear="true">
                        <option value=""><?php echo e(__('Select Pool')); ?></option>
                            <?php $__currentLoopData = $provinsis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>" <?php echo e(old('provinsi_id') == $data->id ? 'selected' : ''); ?>>
                                    <?php echo e($data->nama_provinsi); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-primary" name="action">Submit</button>
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="offcanvas"> Cancel</button>
                </div>
            </div>
          </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tufa\pariwisata-3624\resources\views\layouts\admin\kota\index.blade.php ENDPATH**/ ?>