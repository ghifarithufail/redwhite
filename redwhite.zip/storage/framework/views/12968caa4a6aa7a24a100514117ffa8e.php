<?php $__env->startSection('content'); ?>
<div class="card text-center">
    <h5 class="card-header">Bookings Report</h5>
</div>

<?php
    $totalSum = 0;
    $totalPendapatan = 0;
?>
<?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $bookingTotal = 0;
        foreach ($data->details as $item) {
            $difference = $item->harga_std - $item->total_pengeluaran;
            $totalSum += $difference;
            $bookingTotal += $difference;
        }
        $totalPendapatanPerBooking = ($bookingTotal + $data->biaya_jemput) - $data->diskon;
        $totalPendapatan += $totalPendapatanPerBooking;
    ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="card text-center mt-4">
    <h5 class="card-header">Jumlah Pendapatan : <?php echo e(number_format($totalPendapatan)); ?></h5>
</div>
<?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mt-4">
        <div class="card-body">
            <table class="table table-bordered">
                <tr>
                    <td width="170"><strong>No Booking</strong></td>
                    <td width="1%">:</td>
                    <td><?php echo e($data->no_booking); ?></td>
                </tr>
                <tr>
                    <td width="170"><strong>Nama</strong></td>
                    <td width="1%">:</td>
                    <td><?php echo e($data->customer); ?></td>
                </tr>
                <tr>
                    <td width="170"><strong>Telephone</strong></td>
                    <td width="1%">:</td>
                    <td>0<?php echo e($data->telephone); ?></td>
                </tr>
                <tr>
                    <td width="170"><strong>Tujuan</strong></td>
                    <td width="1%">:</td>
                    <td><?php echo e($data->tujuan->nama_tujuan); ?></td>
                </tr>
            </table>
        </div>
    </div>
    <div class="card mt-4">
        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <table class="table table-bordered">
                    <thead class="thead-light">
                        <tr>
                            <th>Nama</th>
                            <th style="text-align: right">Harga</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $bookingTotal = 0;
                        ?>
                        <?php $__currentLoopData = $data->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $difference = $item->harga_std - $item->total_pengeluaran;
                                $bookingTotal += $difference;
                            ?>
                            <tr>
                                <td><b>Bus</b></td>
                                <td style="text-align: right"><b><i><?php echo e($item->armadas->nobody); ?></i></b></td>
                            </tr>
                            <tr>
                                <td>Harga</td>
                                <td style="text-align: right"><?php echo e(number_format($item->harga_std)); ?></td>
                            </tr>
                            <tr>
                                <td>Pengeluaran</td>
                                <td style="text-align: right"><?php echo e(number_format($item->total_pengeluaran)); ?></td>
                            </tr>
                            <tr>
                                <td style="text-align: right">Total</td>
                                <td style="text-align: right"><b><?php echo e(number_format($difference)); ?></b></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th style="text-align: right">Jumlah : </th>
                            <th style="text-align: right"><b><?php echo e(number_format($bookingTotal)); ?></b></th>
                        </tr>
                        <tr>
                            <th style="text-align: right">Biaya Jemput : </th>
                            <th style="text-align: right"><?php echo e(number_format($data->biaya_jemput)); ?></th>
                        </tr>
                        <tr>
                            <th style="text-align: right">Diskon : </th>
                            <?php if($data->diskon): ?>
                                <th style="text-align: right">-<?php echo e(number_format($data->diskon)); ?></th>
                            <?php else: ?>
                                <th style="text-align: right">0</th>
                            <?php endif; ?>
                        </tr>
                        <?php
                            $totalPendapatanPerBooking = $bookingTotal + $data->biaya_jemput - $data->diskon;
                        ?>
                        <tr>
                            <th style="text-align: right">Total Pendapatan : </th>
                            <th style="text-align: right"><b><?php echo e(number_format($totalPendapatanPerBooking)); ?></b></th>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tufa\pariwisata-3624\resources\views\layouts\booking\report.blade.php ENDPATH**/ ?>