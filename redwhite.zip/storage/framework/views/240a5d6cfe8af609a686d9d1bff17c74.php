<?php $__env->startSection('content'); ?>
<?php if($errors->has('nokondektur')): ?>
    <div class="text-danger">
        <?php echo e($errors->first('nokondektur')); ?>

    </div>
<?php endif; ?>
<div class="card">
    <div class="card-body">
        <h5 class="card-header">Edit Kondektur</h5>
        <hr class="my-0" />
        <div class="card-body">
            <form action="<?php echo e(route('kondektur.update', $kondektur->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <input type="hidden" name="user_id" value="<?php echo e($kondektur->user_id); ?>">
                    <div class="mb-3 col-md-6">
                        <label for="nokondektur" class="form-label">Nomor kondektur</label>
                        <input id="nokondektur" name="nokondektur" type="text" value="<?php echo e(old('nokondektur', $kondektur->nokondektur)); ?>" class="form-control">
                        <?php if($errors->has('nokondektur')): ?>
                            <div class="text-danger">
                                <?php echo e($errors->first('nokondektur')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3 col-md-6">
                        <label for="rute_id" class="form-label">Rute</label>
                        <select id="rute_id" name="rute_id" class="select2 form-select">
                            <option value="">Pilih Rute</option>
                            <?php if(isset($rutes) && count($rutes) > 0): ?>
                                <?php $__currentLoopData = $rutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $pool = $rute->poolS; // Asumsi relasi "pool" ada di model Rute
                                    ?>
                                    <option value="<?php echo e($rute->id); ?>"
                                            data-rute="<?php echo e($rute->kode_route); ?>"
                                            data-pool="<?php echo e($pool ? $pool->id : ''); ?>"
                                            <?php echo e($kondektur->rute_id == $rute->id ? 'selected' : ''); ?>>
                                        <?php echo e($rute->nama_rute); ?> - <?php echo e($pool ? $pool->nama_pool : 'Pool Tidak Tersedia'); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                      <div class="col-md-6">
                        <label class="form-label" for="pool_id">Pool</label>
                        <select id="pool_id" name="pool_id" class="select2 form-select">
                            <option value=""><?php echo e(__('Select Pool')); ?></option>
                            <?php $__currentLoopData = $pools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pool->id); ?>" <?php echo e($kondektur->pool_id == $pool->id ? 'selected' : ''); ?>>
                                    <?php echo e($pool->nama_pool); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3 col-md-6">
                        <label for="tgl_masuk" class="form-label">Tanggal Masuk</label>
                        <input type="date" class="form-control" id="tgl_masuk" name="tgl_masuk" value="<?php echo e($kondektur->tgl_masuk); ?>" />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label for="tanggal_kp" class="form-label">Tanggal KP</label>
                        <input type="date" class="form-control" id="tanggal_kp" name="tanggal_kp" value="<?php echo e($kondektur->tanggal_kp); ?>" />
                    </div>
                    <div class="mb-3 col-md-6">
                        <label for="nojamsostek" class="form-label">Nomor Jamsostek</label>
                        <input type="text" class="form-control" id="nojamsostek" name="nojamsostek" value="<?php echo e($kondektur->nojamsostek); ?>"/>
                        <?php if($errors->has('nojamsostek')): ?>
                            <div class="text-danger">
                                <?php echo e($errors->first('nojamsostek')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label" for="status">Status</label>
                        <select id="status" name="status" class="select2 form-select" required>
                            <option value="[]">Select Status</option>
                            <option value="Active" <?php echo e($kondektur->status == 'Active' ? 'selected' : ''); ?>>Active</option>
                            <option value="Inactive" <?php echo e($kondektur->status == 'Inactive' ? 'selected' : ''); ?>>Inactive</option>
                            <option value="Disable" <?php echo e($kondektur->status == 'Disable' ? 'selected' : ''); ?>>Disable</option>
                        </select>
                        <?php if($errors->has('status')): ?>
                            <div class="text-danger"><?php echo e($errors->first('status')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3 col-md-6">
                        <label for="ket_kondektur" class="form-label">Keterangan</label>
                        <input type="text" class="form-control" id="ket_kondektur" name="ket_kondektur" value="<?php echo e($kondektur->ket_kondektur); ?>"/>
                    </div>

                <div class="mt-2">
                    <button type="submit" class="btn btn-primary" name="action">Submit</button>
                    <a href="<?php echo e(route('kondektur.index')); ?>" class="btn btn-warning">Kembali</a>
                </div>
            </form>
        </div>
        <!-- /Account -->
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
  <script>
      $(document).ready(function () {
          $('#rute_id').select2();
          $('#pool_id').select2();

      });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tufa\pariwisata-3624\resources\views\layouts\hrd\kondektur\edit.blade.php ENDPATH**/ ?>