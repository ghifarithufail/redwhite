<?php $__env->startSection('content'); ?>

<div class="card-body">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <h5 class="card-header">Pengemudi</h5>
    <hr class="my-0" />
    <div class="card-body">
        <form action="<?php echo e(route('pengemudi.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="mb-3 col-md-6">
                    <label for="user_id" class="form-label">User</label>
                    <select id="user_id" name="user_id" class="select2 form-select" data-allow-clear="false">
                        <option value="">Pilih User</option>
                        <?php $__currentLoopData = $users->filter(function($user) {
                            return $user->hasRole('pengemudi') && !empty($user->biodata->nik);
                        }); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->id); ?>" <?php echo e(old('user_id') == $data->id ? 'selected' : ''); ?>>
                                <?php echo e($data->id); ?> - <?php echo e($data->name); ?> - <?php echo e($data->biodata->nik); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('user_id')): ?>
                        <div class="text-danger"><?php echo e($errors->first('user_id')); ?></div>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-6">
                    <label for="nopengemudi" class="form-label">Nomor Pengemudi</label>
                    <input id="nopengemudi" name="nopengemudi" type="text" value="<?php echo e(\App\Models\Hrd\Pengemudi::generateNopengemudi()); ?>" class="form-control">
                    <?php $__errorArgs = ['nopengemudi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="toast-header">
                            <div class="text-danger"><?php echo e($message); ?></div>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label" for="rute_id">Rute</label>
                    <select id="rute_id" name="rute_id" class="select2 form-select">
                        <option value=""><?php echo e(__('Select Rute')); ?></option>
                        <?php $__currentLoopData = $rutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($rute->id); ?>" <?php echo e(old('rute_id') == $rute->id ? 'selected' : ''); ?>>
                                <?php echo e($rute->nama_rute); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('rute_id')): ?>
                        <div class="text-danger"><?php echo e($errors->first('rute_id')); ?></div>
                    <?php endif; ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label" for="pool_id">Pool</label>
                    <select id="pool_id" name="pool_id" class="form-select select2" data-allow-clear="true">
                        <option value=""><?php echo e(__('Select Pool')); ?></option>
                        <?php $__currentLoopData = $pools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pool->id); ?>" <?php echo e(old('pool_id') == $pool->id ? 'selected' : ''); ?>>
                                <?php echo e($pool->nama_pool); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('pool_id')): ?>
                        <div class="text-danger"><?php echo e($errors->first('pool_id')); ?></div>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-6">
                    <label for="tgl_masuk" class="form-label">Tanggal Masuk</label>
                    <input type="date" class="form-control" id="tgl_masuk" name="tgl_masuk" value="<?php echo e(old('tgl_masuk')); ?>" />
                    <?php if($errors->has('tgl_masuk')): ?>
                        <div class="text-danger"><?php echo e($errors->first('tgl_masuk')); ?></div>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-6">
                    <label for="tanggal_kp" class="form-label">Tanggal KP</label>
                    <input type="date" class="form-control" id="tanggal_kp" name="tanggal_kp" value="<?php echo e(old('tanggal_kp')); ?>" />
                    <?php if($errors->has('tanggal_kp')): ?>
                        <div class="text-danger"><?php echo e($errors->first('tanggal_kp')); ?></div>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-6">
                    <label for="nosim" class="form-label">Nomor SIM</label>
                    <input type="text" class="form-control" id="nosim" name="nosim" value="<?php echo e(old('nosim')); ?>"/>
                    <?php if($errors->has('nosim')): ?>
                        <div class="text-danger"><?php echo e($errors->first('nosim')); ?></div>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-6">
                    <label class="form-label" for="jenis_sim">Jenis SIM</label>
                    <select id="jenis_sim" name="jenis_sim" class="select2 form-select" required>
                        <option value="">Select Jenis SIM</option>
                        <option value="BI" <?php echo e(old('jenis_sim') == 'BI' ? 'selected' : ''); ?>>BI</option>
                        <option value="BI-Umum" <?php echo e(old('jenis_sim') == 'BI-Umum' ? 'selected' : ''); ?>>BI-Umum</option>
                        <option value="BII" <?php echo e(old('jenis_sim') == 'BII' ? 'selected' : ''); ?>>BII</option>
                        <option value="BII-Umum" <?php echo e(old('jenis_sim') == 'BII-Umum' ? 'selected' : ''); ?>>BII-Umum</option>
                    </select>
                    <?php if($errors->has('jenis_sim')): ?>
                        <div class="text-danger"><?php echo e($errors->first('jenis_sim')); ?></div>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-6">
                    <label for="tgl_sim" class="form-label">Tanggal SIM</label>
                    <input type="date" class="form-control" id="tgl_sim" name="tgl_sim" value="<?php echo e(old('tgl_sim')); ?>"/>
                    <?php if($errors->has('tgl_sim')): ?>
                        <div class="text-danger"><?php echo e($errors->first('tgl_sim')); ?></div>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-6">
                    <label for="nojamsostek" class="form-label">Nomor Jamsostek</label>
                    <input type="text" class="form-control" id="nojamsostek" name="nojamsostek" value="<?php echo e(old('nojamsostek')); ?>"/>
                    <?php if($errors->has('nojamsostek')): ?>
                        <div class="text-danger"><?php echo e($errors->first('nojamsostek')); ?></div>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-6">
                    <label class="form-label" for="status">Status</label>
                    <select id="status" name="status" class="select2 form-select" required>
                        <option value="[]">Select Status</option>
                        <option value="Active" <?php echo e(old('status') == 'Active' ? 'selected' : ''); ?>>Active</option>
                        <option value="Inactive" <?php echo e(old('status') == 'Inactive' ? 'selected' : ''); ?>>Inactive</option>
                        <option value="Disable" <?php echo e(old('status') == 'Disable' ? 'selected' : ''); ?>>Disable</option>
                    </select>
                    <?php if($errors->has('status')): ?>
                        <div class="text-danger"><?php echo e($errors->first('status')); ?></div>
                    <?php endif; ?>
                </div>

                <div class="mb-3 col-md-6">
                    <label for="ket_pengemudi" class="form-label">Keterangan</label>
                    <input type="text" class="form-control" id="ket_pengemudi" name="ket_pengemudi" value="<?php echo e(old('ket_pengemudi')); ?>"/>
                    <?php if($errors->has('ket_pengemudi')): ?>
                        <div class="text-danger"><?php echo e($errors->first('ket_pengemudi')); ?></div>
                    <?php endif; ?>
                </div>

                <div class="mt-2">
                    <button type="submit" class="btn btn-primary" name="action">Submit</button>
                    <a href="<?php echo e(route('pengemudi.index')); ?>" class="btn btn-warning">Kembali</a>
                </div>
            </div>
        </form>
    </div>
        <!-- /Account -->
    </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script>
        <?php if(session('success')): ?>
            toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

        // Jika terdapat pesan error dari server, tampilkan pesan toastr
        <?php if(session('error')): ?>
            toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

        $(document).ready(function () {
            $('#rute_id').select2(); // Initialize Select2 on the dropdown

            $('#rute_id').change(function () {
                var selectedOption = $(this).children("option:selected");
                var id = selectedOption.data('pool'); // Access pool ID

                if (id) {
                    // Use AJAX to retrieve pool name based on pool ID
                    $.ajax({
                        url: '/get-pool-name/' + id, // Adjust URL according to your route
                        type: 'GET',
                        success: function (response) {
                            $('#nama_pool').val(response.nama_pool); // Fill the pool name into the input field
                        },
                        error: function (xhr, status, error) {
                            console.error(error);
                        }
                    });
                } else {
                    // If no pool ID is available, clear the input field
                    $('#nama_pool').val('');
                }
            });

            // Trigger event 'change' for autofill on page load
            $('#rute_id').trigger('input');
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tufa\pariwisata-3624\resources\views\layouts\hrd\pengemudi\create.blade.php ENDPATH**/ ?>