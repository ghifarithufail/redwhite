<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(isset($tujuan) ? route('tujuan.update', $tujuan->id) : route('tujuan.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($tujuan)): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>

                    <div class="row g-3">
                        <h5><?php echo e(isset($tujuan) ? 'EDIT TUJUAN' : 'CREATE TUJUAN'); ?></h5>
                        <div class="col-md-6">
                            <label class="form-label" for="nama_tujuan">Nama tujuan</label>
                            <input type="text" class="form-control" id="nama_tujuan" name="nama_tujuan" value="<?php echo e(old('nama_tujuan', isset($tujuan) ? $tujuan->nama_tujuan : '')); ?>"/>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="pemakaian">Pemakaian</label>
                            <input type="text" class="form-control" id="pemakaian" name="pemakaian" value="<?php echo e(old('pemakaian', isset($tujuan) ? $tujuan->pemakaian : '')); ?>"/>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="type_bus">Type Bus</label>
                            <select id="type_bus" name="type_bus" class="select2 form-select" required>
                                <option value="">Select type_bus</option>
                                <option value="SINGEL GLASS" <?php echo e(old('type_bus', isset($tujuan) && $tujuan->type_bus == 'SINGEL GLASS' ? 'selected' : '')); ?>>SINGEL GLASS</option>
                                <option value="DOUBLE GLASS" <?php echo e(old('type_bus', isset($tujuan) && $tujuan->type_bus == 'DOUBLE GLASS' ? 'selected' : '')); ?>>DOUBLE GLASS</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="harga_std">Harga Standar</label>

                            <input type="text" class="form-control" id="harga_std" name="harga_std" value="<?php echo e(!empty(old('harga_std')) ? number_format(old('harga_std'), 0, ',', '.') : ''); ?>"/>
                        </div>
                        <div class="pt-4">
                            <button id="submit" type="submit" class="btn btn-primary mr-2"><?php echo e(isset($tujuan) ? 'Update' : 'Create'); ?></button>
                            <a href="<?php echo e(route('tujuan.index')); ?>" class="btn btn-warning">Kembali</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const hargaStdInput = document.getElementById('harga_std');

            hargaStdInput.addEventListener('input', function (e) {
                let value = e.target.value.replace(/\D/g, ''); // Hapus karakter selain angka
                e.target.value = value.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tufa\pariwisata-3624\resources\views\layouts\cso\tujuan\create.blade.php ENDPATH**/ ?>