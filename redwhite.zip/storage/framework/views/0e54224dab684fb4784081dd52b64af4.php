<?php $__env->startSection('content'); ?>

<div class="container-xxl">
    <div class="card mb-4">
        <h5 class="card-header">Edit Biodata</h5>
        <div class="card-body">
            <form action="<?php echo e(route('biodata.update', $biodata->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row g-2">
                    <div class="mb-3 col-md-4">
                        <label for="user_id" class="form-label">User</label>
                        <select id="user_id" name="user_id" class="select2 form-select" data-allow-clear="false">
                            <option value="">Pilih User</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $roleName = $user->roles->first()->name ?? 'No Role';
                            ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e($biodata->user_id == $user->id ? 'selected' : ''); ?>>
                                <?php echo e($user->id); ?> - <?php echo e($user->name); ?> - <?php echo e($roleName); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <!-- Sisipkan data biodata yang ingin diubah -->
                    <div class="mb-2 col-md-4">
                        <label for="nik" class="form-label">Nomor KTP</label>
                        <input id="nik" type="text" name="nik" class="form-control" value="<?php echo e($biodata->nik); ?>" minlength="3" required>
                        <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger text-sm "><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-2 col-md-4">
                        <label for="nokk" class="form-label">Nomor KTP</label>
                        <input id="nokk" type="text" name="nokk" class="form-control" value="<?php echo e($biodata->nokk); ?>" minlength="3" required>
                        <?php $__errorArgs = ['nokk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <!-- Sisipkan data biodata yang ingin diubah -->
                <div class="row g-2">
                    <div class="mb-2 col-md-6">
                        <label class="form-label" for="kota_id">Tempat Lahir</label>
                        <select id="kota_id" name="kota_id" class="select2 form-select" data-allow-clear="true">
                            <option value=""><?php echo e(__('Select Kota')); ?></option>
                            <?php $__currentLoopData = $kotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->id); ?>" <?php echo e($biodata->kota_id == $data->id ? 'selected' : ''); ?>>
                                <?php echo e($data->nama_kota); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <!-- Sisipkan data biodata yang ingin diubah -->
                    <div class="mb-2 col-md-6">
                        <label for="tgl_lahir" class="form-label">Tanggal Lahir</label>
                        <input id="tgl_lahir" type="date" name="tgl_lahir" class="form-control" value="<?php echo e($biodata->tgl_lahir); ?>" required>
                        <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <!-- Sisipkan data biodata yang ingin diubah -->
                <div class="row g-2">
                    <div class="mb-2 col-md-4">
                        <label class="form-label" for="nikah">Perkawinan</label>
                        <select id="nikah" name="nikah" class="select2 form-select" required>
                            <option value="Singel" <?php echo e($biodata->nikah == 'Singel' ? 'selected' : ''); ?>>Singel</option>
                            <option value="Menikah" <?php echo e($biodata->nikah == 'Menikah' ? 'selected' : ''); ?>>Menikah</option>
                            <option value="Cerai" <?php echo e($biodata->nikah == 'Cerai' ? 'selected' : ''); ?>>Cerai</option>
                        </select>
                    </div>
                    <!-- Sisipkan data biodata yang ingin diubah -->
                    <div class="mb-2 col-md-4">
                        <label class="form-label" for="status">Agama</label>
                        <select id="agama" name="agama" class="select2 form-select" required>
                            <option value="Islam" <?php echo e($biodata->agama == 'Islam' ? 'selected' : ''); ?>>Islam</option>
                            <option value="Kristen" <?php echo e($biodata->agama == 'Kristen' ? 'selected' : ''); ?>>Kristen</option>
                            <option value="Hindu" <?php echo e($biodata->agama == 'Hindu' ? 'selected' : ''); ?>>Hindu</option>
                            <option value="Budha" <?php echo e($biodata->agama == 'Budha' ? 'selected' : ''); ?>>Budha</option>
                        </select>
                    </div>
                    <!-- Sisipkan data biodata yang ingin diubah -->
                    <div class="mb-2 col-md-4">
                        <label class="form-label" for="jenis">Jenis</label>
                        <select id="jenis" name="jenis" class="select2 form-select" required>
                            <option value="Laki" <?php echo e($biodata->jenis == 'Laki' ? 'selected' : ''); ?>>Laki</option>
                            <option value="Perempuan" <?php echo e($biodata->jenis == 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                        </select>
                    </div>
                </div>
                <!-- Sisipkan data biodata yang ingin diubah -->
                <div class="row g-2">
                    <div class="mb-2 col-md-8">
                        <label for="alamat" class="form-label">Alamat</label>
                        <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo e($biodata->alamat); ?>" />
                    </div>
                    <!-- Sisipkan data biodata yang ingin diubah -->
                    <div class="mb-2 col-md-2">
                        <label for="rt" class="form-label">RT</label>
                        <input type="text" class="form-control" id="rt" name="rt" value="<?php echo e($biodata->rt); ?>" />
                    </div>
                    <div class="mb-2 col-md-2">
                        <label for="rw" class="form-label">RW</label>
                        <input type="text" class="form-control" id="rw" name="rw" value="<?php echo e($biodata->rw); ?>" />
                    </div>
                </div>
                <!-- Sisipkan data biodata yang ingin diubah -->
                <div class="row g-2">
                    <div class="mb-2 col-md-6">
                        <label for="image" class="form-label">Image</label>
                        <input type="file" class="form-control" id="image" name="image">
                    </div>
                </div>
                <?php if($biodata->image): ?>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Existing Image</label>
                        <div>
                            <img src="<?php echo e(asset('storage/images/' . $biodata->image)); ?>"
                                 alt="Existing Image" class="img-fluid" width="100" height="100">
                        </div>
                    </div>
                <?php endif; ?>
                <div class="mt-4">
                    <button type="submit" class="btn btn-primary" name="action">Submit</button>
                    <a href="<?php echo e(route('biodata.index')); ?>" class="btn btn-warning">Kembali</a>
                </div>
        </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tufa\pariwisata-3624\resources\views\layouts\hrd\biodata\edit.blade.php ENDPATH**/ ?>