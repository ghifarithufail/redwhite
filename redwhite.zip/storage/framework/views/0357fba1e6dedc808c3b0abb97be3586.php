<?php $__env->startSection('content'); ?>

<div class="card text-center">
    <div class="card-header d-flex justify-content-between align-items-center">
        <div class="search-field">
            <form action="<?php echo e(route('armada.index')); ?>" method="GET">
                <input type="text" name="search" class="form-control" placeholder="Search...">
            </form>
        </div>
        <div>
            <a href="<?php echo e(route('armada.index')); ?>" class="m-0"><h5> Daftar Armada</h5></a>
            <p class="m-0">Total : <?php echo e(App\Models\Armada::count()); ?> </p>
        </div>
        <div class="add-new-role">
            <!-- Tombol "Add New Role" -->
            <button data-bs-target="#addarmadaModal" data-bs-toggle="modal" class="btn btn-primary mb-2 text-nowrap">
                + Armada
            </button>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="table-responsive text-nowrap">
        <table class="table table-hover" style="zoom: 0.85">
            <thead>
                <tr>
                    <th>No.Urt</th>
                    <th>Nomor Body</th>
                    <th>Nomor Chassis</th>
                    <th>Nomor Mesin</th>
                    <th>Nomor Polisi</th>
                    <th>Rute</th>
                    <th>Nama Rute</th>
                    <th>Pool</th>
                    <th>Merk</th>
                    <th>Tahun</th>
                    <th>Jenis</th>
                    <th>Seat</th>
                    <th>Type</th>
                    <th>Kondisi</th>
                    <th>Keterangan</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody class="table-border-bottom-0">
                <?php $__currentLoopData = $armadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="font-size: 14px"><?php echo e($armadas->firstItem() + $loop->index); ?></td>
                    <td style="font-size: 14px"><?php echo e($data->nobody); ?></td>
                    <td style="font-size: 14px"><?php echo e($data->nochassis); ?></td>
                    <td style="font-size: 14px"><?php echo e($data->nomesin); ?></td>
                    <td style="font-size: 14px"><?php echo e($data->nopolisi); ?></td>
                    <td style="font-size: 14px"><?php echo e($data->rutes->kode_rute ?? '-'); ?></td>
                    <td style="font-size: 14px"><?php echo e($data->rutes->nama_rute ?? '-'); ?></td>
                    <td style="font-size: 14px"><?php echo e($data->rutes->pools->nama_pool ?? '-'); ?></td>
                    <td style="font-size: 14px"><?php echo e($data->merk); ?></td>
                    <td style="font-size: 14px"><?php echo e($data->tahun); ?></td>
                    <td style="font-size: 14px"><?php echo e($data->jenis); ?></td>
                    <td style="font-size: 14px"><?php echo e($data->seat); ?></td>
                    <td style="font-size: 14px"><?php echo e($data->type_armada->name ?? '-'); ?></td>
                    <td style="font-size: 14px">
                        <?php if($data->kondisi == 'Baik'): ?>
                            <label class="flex items-center justify-center text-success">Baik</label>
                        <?php elseif($data->kondisi =='Sedang'): ?>
                            <label class="flex items-center justify-center text-warning">Sedang</label>
                        <?php elseif($data->kondisi =='Buruk'): ?>
                            <label class="flex items-center justify-center text-danger">Buruk</label>
                        <?php else: ?>
                        <?php endif; ?>
                    </td>
                    <td style="font-size: 14px"><?php echo e($data->keterangan); ?></td>
                    <td style="font-size: 14px">
                        <div class="dropdown text-center">
                            <a href="<?php echo e(route('armada.edit', $data->id)); ?>">
                                <button type="button" class="btn rounded-pill btn-icon btn-warning">
                                    <span class="tf-icons bx bx-edit"></span>
                                </button>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="intro-y col-span-12">
        <div class="card-footer">
            <?php echo e($armadas->onEachSide(1)->links('pagination::bootstrap-5')); ?>

        </div>
    </div>
</div>

<!-- Add Role Modal -->
<div class="modal fade" id="addarmadaModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-simple modal-edit-armada">
        <div class="modal-content p-3 p-md-5">
            <div class="modal-body">
                
                <div class="text-center mb-4">
                    <h3 class="mb-2">Tambah Armada</h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('armada.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <!-- Input untuk armada -->
                            <div class="mb-3 col-md-6">
                                <label for="nobody" class="form-label">Nomor Body</label>
                                <input id="nobody" type="text" name="nobody" class="form-control" value="<?php echo e(old('nobody')); ?>" minlength="3" required>
                                <?php $__errorArgs = ['nobody'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="nopolisi" class="form-label">Nomor Polisi</label>
                                <input id="nopolisi" type="text" name="nopolisi" class="form-control" value="<?php echo e(old('nopolisi')); ?>" minlength="3" required>
                                <?php $__errorArgs = ['nopolisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="nochassis">Nomor Chassis</label>
                                <input type="text" class="form-control" id="nochassis" name="nochassis" value="<?php echo e(old('nochassis')); ?>"/>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="nomesin">Nomor Mesin</label>
                                <input type="text" class="form-control" id="nomesin" name="nomesin" value="<?php echo e(old('nomesin')); ?>"/>
                            </div>
                           <div class="mb-3 col-md-6">
                                <label class="form-label" for="rute_id">Rute</label>
                                <select id="rute_id" name="rute_id" class="select2 form-select" data-allow-clear="true">
                                    <option value=""><?php echo e(__('Select Rute')); ?></option>
                                    <?php $__currentLoopData = $rutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($rute->id); ?>" <?php echo e(old('rute_id') == $rute->id ? 'selected' : ''); ?>>
                                            <?php echo e($rute->kode_rute); ?> - <?php echo e($rute->nama_rute); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="merk">Merk</label>
                                <select id="merk" name="merk" class="select2 form-select" required>
                                    <option value="">Select Merk</option>
                                    <option value="HINO RG" <?php echo e(old('merk') == 'HINO RG' ? 'selected' : ''); ?>>HINO RG</option>
                                    <option value="HINO RJK" <?php echo e(old('merk') == 'HINO RJK' ? 'selected' : ''); ?>>HINO RJK</option>
                                </select>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="tahun">Tahun</label>
                                <input type="number" class="form-control" id="tahun" name="tahun" value="<?php echo e(old('tahun')); ?>"/>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="jenis">Jenis Layanan</label>
                                <select id="jenis" name="jenis" class="select2 form-select" required>
                                    <option value="">Select Status</option>
                                    <option value="EKONOMI" <?php echo e(old('jenis') == 'EKONOMI' ? 'selected' : ''); ?>>EKONOMI</option>
                                    <option value="AC EKONOMI" <?php echo e(old('jenis') == 'AC EKONOMI' ? 'selected' : ''); ?>>AC EKONOMI</option>
                                    <option value="AC BISNIS" <?php echo e(old('jenis') == 'AC BISNIS' ? 'selected' : ''); ?>>AC BISNIS</option>
                                    <option value="EXECUTIVE" <?php echo e(old('jenis') == 'EXECUTIVE' ? 'selected' : ''); ?>>EXECUTIVE</option>
                                    <option value="SUPER EXECUTIVE" <?php echo e(old('jenis') == 'SUPER EXECUTIVE' ? 'selected' : ''); ?>>SUPER EXECUTIVE</option>
                                    <option value="WISATA" <?php echo e(old('jenis') == 'WISATA' ? 'selected' : ''); ?>>WISATA</option>
                                </select>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="seat">Seat</label>
                                <input type="number" class="form-control" id="seat" name="seat" value="<?php echo e(old('seat')); ?>"/>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="type_id">Type Armada</label>
                                <select id="type_id" name="type_id" class="select2 form-select" data-allow-clear="true">
                                    <option value=""><?php echo e(__('Select Type')); ?></option>
                                    <?php $__currentLoopData = $typearmadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>" <?php echo e(old('type_id') == $type->id ? 'selected' : ''); ?>>
                                            <?php echo e($type->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="kondisi">Kondisi</label>
                                <select id="kondisi" name="kondisi" class="select2 form-select" required>
                                    <option value="">Select Kondisi</option>
                                    <option value="Baik" <?php echo e(old('kondisi') == 'Baik' ? 'selected' : ''); ?>>Baik</option>
                                    <option value="Sedang" <?php echo e(old('kondisi') == 'Sedang' ? 'selected' : ''); ?>>Sedang</option>
                                    <option value="Rusak" <?php echo e(old('kondisi') == 'Rusak' ? 'selected' : ''); ?>>Rusak</option>
                                </select>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label class="form-label" for="keterangan">Keterangan</label>
                                <input type="keterangan" class="form-control" id="keterangan" name="keterangan" value="<?php echo e(old('keterangan')); ?>"/>
                            </div>
                            <div class="mt-2">
                                <button type="submit" class="btn btn-primary" name="action">Submit</button>
                                <a href="<?php echo e(route('armada.index')); ?>" class="btn btn-warning">Cancel</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
    // Jika terdapat pesan sukses dari server, tampilkan pesan toastr
    <?php if(session('success')): ?>
    toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

    // Jika terdapat pesan error dari server, tampilkan pesan toastr
    <?php if(session('error')): ?>
    toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tufa\pariwisata-3624\resources\views\layouts\admin\armada\index.blade.php ENDPATH**/ ?>