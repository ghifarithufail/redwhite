<?php $__env->startSection('content'); ?>

<div class="card text-center">
    <div class="card-header d-flex justify-content-between align-items-center">
        <div class="search-field">
            <form action="<?php echo e(route('pool.index')); ?>" method="GET">
                <input type="text" name="search" class="form-control" placeholder="Search...">
            </form>
        </div>
        <div>
            <a href="<?php echo e(route('pool.index')); ?>" class="m-0"><h5> Daftar Pool</h5></a>
            <p class="m-0">Total : <?php echo e(App\Models\Admin\pool::count()); ?> </p>
        </div>
        <div class="add-new-role">
            <!-- Tombol "Add New Role" -->
            <button data-bs-target="#addUserModal" data-bs-toggle="modal" class="btn btn-primary mb-2 text-nowrap">
                + Pool
            </button>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="table-responsive text-nowrap">
        <table class="table table-hover" style="zoom: 0.85">
            <thead>
                <tr>
                    <th>Nama pool</th>
                    <th>Alamat</th>
                    <th>Telephone</th>
                    <th>Status</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody class="table-border-bottom-0">
                <?php $__currentLoopData = $pools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($data->nama_pool); ?></td>
                    <td><?php echo e($data->alamat); ?></td>
                    <td><?php echo e($data->phone); ?></td>
                    <td>
                        <?php if($data->status == 'Active'): ?>
                        <label class="flex items-center justify-center text-success">Active</label>
                        <?php elseif($data->status =='Inactive'): ?>
                            <label class="flex items-center justify-center text-warning">Inactive</label>
                        <?php elseif($data->status =='Disable'): ?>
                            <label class="flex items-center justify-center text-warning">Disable</label>
                        <?php else: ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="dropdown text-center">
                            <a href="<?php echo e(route('pool.edit', $data->id)); ?>">
                                <button type="button" class="btn btn-secondary" fdprocessedid="c80zr4">
                                    <i class='bx bx-edit' ></i>
                                    Edit
                                </button>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="intro-y col-span-12">
        <div class="card-footer">
            <?php echo e($pools->onEachSide(1)->links('pagination::bootstrap-5')); ?>

        </div>
    </div>
</div>

<!-- Add Role Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-simple modal-edit-user">
        <div class="modal-content p-3 p-md-5">
            <div class="modal-body">
                
                <div class="text-center mb-4">
                    <h3 class="mb-2">Tambah pool</h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('pool.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <!-- Input untuk user -->
                            <div class="mb-3 col-md-6">
                                <label for="nama_pool" class="form-label">Nama pool</label>
                                <input id="nama_pool" type="text" name="nama_pool" class="form-control" value="<?php echo e(old('nama_pool')); ?>" minlength="3" required>
                                <?php $__errorArgs = ['nama_pool'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="alamat" class="form-label">Alamat Pool</label>
                                <input id="alamat" type="text" name="alamat" class="form-control" value="<?php echo e(old('alamat')); ?>" minlength="3" required>
                                <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="phone" class="form-label">Alamat Pool</label>
                                <input id="phone" type="text" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>" minlength="3" required>
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mt-2">
                                <button type="submit" class="btn btn-primary" name="action">Submit</button>
                                <a href="<?php echo e(route('pool.index')); ?>" class="btn btn-warning">Cancel</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
    // Jika terdapat pesan sukses dari server, tampilkan pesan toastr
    <?php if(session('success')): ?>
    toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

    // Jika terdapat pesan error dari server, tampilkan pesan toastr
    <?php if(session('error')): ?>
    toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tufa\pariwisata-3624\resources\views\layouts\admin\pool\index.blade.php ENDPATH**/ ?>