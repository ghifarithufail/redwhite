<?php $__env->startSection('content'); ?>

<div class="container-xxl">
    <div class="card mb-4">
        <h5 class="card-header">Edit User</h5>
        <!-- Role -->
        <div class="card-body">
                    <form action="<?php echo e(route('roles.update', $role->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Role Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($role->name); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Permissions</label><br>
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="permission_<?php echo e($permission->id); ?>" name="permissions[]" value="<?php echo e($permission->id); ?>">
                                    <label class="form-check-label" for="permission_<?php echo e($permission->id); ?>"><?php echo e($permission->name); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Role</button>
                        <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-warning">Back</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tufa\pariwisata-3624\resources\views\layouts\admin\role\edit.blade.php ENDPATH**/ ?>