<?php $__env->startSection('content'); ?>

    <head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    </head>
    <div class="card text-center">
        <h5 class="card-header">SPJ</h5>
    </div>
    <div class="card mt-4">
        <div class="table-responsive text-nowrap">
            <table class="table table-hover" style="zoom: 0.75">
                <thead>
                    <tr>
                        <th>Nama Bus</th>
                        <th>Kondektur</th>
                        <th>Supir</th>
                        <th class="text-center">SPJ</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->armadas ? $data->armadas->nobody : ''); ?></td>
                            <td><?php echo e($data->supir_id); ?></td>
                            <td><?php echo e($data->Kondektur_id); ?></td>
                            <td class="text-center">
                                <?php if($data->is_out == null): ?>
                                    <form method="POST" action="<?php echo e(route('spj/keluar', $data->id)); ?>"
                                        style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn rounded-pill btn-danger"
                                            fdprocessedid="c80zr4">SPJ KELUAR</button>
                                    </form>
                                <?php elseif($data->is_in == null): ?>
                                    
                                    <a href="<?php echo e(route('spj/print_in', $data->spjs->id)); ?>">
                                        <button type="button" class="btn rounded-pill btn-success" fdprocessedid="c80zr4">SPJ Masuk</button>
                                    </a>
                                <?php else: ?>
                                    done
                                <?php endif; ?>
                            </td>
                            <?php if($data->spjs && $data->is_in == null): ?>
                            <td>
                                <a href="<?php echo e(route('spj/data', $data->spjs->id)); ?>">
                                    <button type="button" class="btn rounded-pill btn-warning" fdprocessedid="c80zr4">Biaya
                                        Lain</button>
                                </a>
                            </td>
                            <?php endif; ?>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script>
        // Jika terdapat pesan sukses dari server, tampilkan pesan toastr
        <?php if(session('success')): ?>
            toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

        // Jika terdapat pesan error dari server, tampilkan pesan toastr
        <?php if(session('error')): ?>
            toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pariwisata\resources\views/layouts/spj/detail.blade.php ENDPATH**/ ?>